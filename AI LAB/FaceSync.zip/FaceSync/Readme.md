# Face ID System - User Guide

## Quick Start Guide

To use the Face ID system, you need to install the required libraries and set up the model.

### Required Libraries

```bash
pip install torch torchvision
pip install facenet-pytorch
pip install opencv-python
pip install numpy
pip install pillow
pip install tqdm matplotlib
```

### Using the Application

1. Navigate to the models folder and download the pre-trained model from the provided Google Drive link
2. Place the .pth file in the models folder
3. Run the application with:
   ```bash
   python faceid_app.py
   ```

## Training Your Own Model (Optional)

If you want to train your own model from scratch:

1. Download the dataset:
   ```bash
   python download_dataset.py
   ```

2. Preprocess the dataset:
   ```bash
   python PreProcessing_dataset.py
   ```

3. Train the model:
   ```bash
   python train_model.py
   ```

4. To improve an existing model:
   ```bash
   python continue_training.py
   ```

## Troubleshooting

- **Camera not working**: Make sure your webcam is properly connected and not being used by another application
- **Recognition accuracy issues**: Try registering your face in different lighting conditions for better results
- **Model not found error**: Verify that the model file is correctly placed in the `models` folder

## System Requirements

- Python 3.7 or newer
- Webcam
- 4GB RAM minimum (8GB+ recommended)
- For training: NVIDIA GPU recommended (not required for just using the application)